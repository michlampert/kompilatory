#!/usr/bin/python

import scanner
import ply.yacc as yacc


tokens = scanner.tokens

precedence = (
   ("left", '+', '-', "DOTADD", "DOTSUB"),
   ("left", '*',  '/', "DOTMUL", "DOTDIV"),
   ("left", "LT", "GT", "NGT", "NLT", "NEQ", "EQ"),
   ("left", "=",  "ADDASSIGN", "SUBASSIGN", "MULASSIGN", "DIVASSIGN"),
   ("right", "EYE", "ONES", "ZEROS"),
   ("right", "TRANSPOSITION"),
   ("right", ":"),
   ("right", "OPPOSITE"),
   ("nonassoc", 'IFX'),
   ("nonassoc", 'ELSE')
)


def p_error(p):
    if p:
        print("Syntax error at line {0}: LexToken({1}, '{2}')".format(p.lineno, p.type, p.value))
    else:
        print("Unexpected end of input")


def p_program(p):
    """program : instruction
                | program instruction"""

def p_instruction(p):
    """instruction : for_instruction
                   | while_instruction
                   | if_instruction
                   | print_instruction
                   | '{' instructions_list '}'
                   | BREAK ';'
                   | CONTINUE ';'
                   | RETURN expression ';'
                   | expression ';'

       instructions_list : instructions_list ';' instruction
                         | instruction"""

def p_boolean_expr(p):
    """boolean_expr : arithmetic_expr LT arithmetic_expr
                    | arithmetic_expr GT arithmetic_expr
                    | arithmetic_expr NGT arithmetic_expr
                    | arithmetic_expr NLT arithmetic_expr
                    | arithmetic_expr EQ arithmetic_expr
                    | arithmetic_expr NEQ arithmetic_expr 
                    | STRING EQ STRING
                    | STRING NEQ STRING"""

def p_arithmetic_expr(p):
    """arithmetic_expr : ID
                       | INTNUM
                       | FLOAT
                       | '[' ']' 
                       | '[' arithmetic_list ']'
                       | ID '[' arithmetic_list ']'
                       | arithmetic_expr '+' arithmetic_expr
                       | arithmetic_expr '-' arithmetic_expr
                       | arithmetic_expr '*' arithmetic_expr
                       | arithmetic_expr '/' arithmetic_expr
                       | arithmetic_expr DOTADD arithmetic_expr
                       | arithmetic_expr DOTMUL arithmetic_expr
                       | arithmetic_expr DOTSUB arithmetic_expr
                       | arithmetic_expr DOTDIV arithmetic_expr 
                       | arithmetic_expr TRANSPOSITION
                       | '-' arithmetic_expr %prec OPPOSITE
                       | EYE '(' arithmetic_expr ')'
                       | ONES '(' arithmetic_expr ')'
                       | ZEROS '(' arithmetic_expr ')'
    
       arithmetic_list : arithmetic_list ',' arithmetic_expr
                       | arithmetic_expr 
       """

def p_assign_expr(p):
    """assign_expr : arithmetic_expr '=' arithmetic_expr
                    | arithmetic_expr ADDASSIGN arithmetic_expr 
                    | arithmetic_expr SUBASSIGN arithmetic_expr
                    | arithmetic_expr MULASSIGN arithmetic_expr
                    | arithmetic_expr DIVASSIGN arithmetic_expr
                    | arithmetic_expr '=' boolean_expr
                    | arithmetic_expr '=' STRING """

def p_expression(p):
    """expression : assign_expr
                  | arithmetic_expr
                  | boolean_expr
    """

def p_if_instruction(p):
    """if_instruction : IF '(' boolean_expr ')' instruction %prec IFX
                      | IF '(' boolean_expr ')' instruction ELSE instruction"""

def p_while_instruction(p):
    """while_instruction : WHILE '(' boolean_expr ')' instruction"""

def p_for_instruction(p):
    """range : arithmetic_expr ':' arithmetic_expr
       for_instruction : FOR ID '=' range instruction"""

def p_print_instruction(p):
    """ print_instruction : PRINT arithmetic_list ';'
                          | PRINT boolean_expr ';'
                          | PRINT STRING ';' """

parser = yacc.yacc()